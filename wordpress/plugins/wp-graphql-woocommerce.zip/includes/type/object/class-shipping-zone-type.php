<?php
/**
 * WPObject Type - Shipping_Zone_Type
 *
 * Registers ShippingZone WPObject type and queries
 *
 * @package WPGraphQL\WooCommerce\Type\WPObject
 * @since   0.20.0
 */

namespace WPGraphQL\WooCommerce\Type\WPObject;

use GraphQL\Type\Definition\ResolveInfo;
use WPGraphQL\AppContext;
use WPGraphQL\WooCommerce\Data\Connection\Shipping_Method_Connection_Resolver;

/**
 * Class Shipping_Zone_Type
 */
class Shipping_Zone_Type {
	/**
	 * Registers shipping zone type
	 *
	 * @return void
	 */
	public static function register() {
		register_graphql_object_type(
			'ShippingZone',
			[
				'description' => static function () {
					return __( 'A Shipping zone object', 'graphql-for-ecommerce' );
				},
				'interfaces'  => [ 'Node' ],
				'fields'      => [
					'id'         => [
						'type'        => [ 'non_null' => 'ID' ],
						'description' => static function () {
							return __( 'The globally unique identifier for the tax rate.', 'graphql-for-ecommerce' );
						},
					],
					'databaseId' => [
						'type'        => 'Int',
						'description' => static function () {
							return __( 'The ID of the customer in the database', 'graphql-for-ecommerce' );
						},
					],
					'name'       => [
						'type'        => 'String',
						'description' => static function () {
							return __( 'Shipping zone name.', 'graphql-for-ecommerce' );
						},
					],
					'order'      => [
						'type'        => 'Int',
						'description' => static function () {
							return __( 'Shipping zone order.', 'graphql-for-ecommerce' );
						},
					],
					'locations'  => [
						'type'        => [ 'list_of' => 'ShippingLocation' ],
						'description' => static function () {
							return __( 'Shipping zone locations.', 'graphql-for-ecommerce' );
						},
					],
				],
				'connections' => [
					'methods' => [
						'toType'     => 'ShippingMethod',
						'edgeFields' => [
							'id'         => [
								'type'        => [ 'non_null' => 'ID' ],
								'description' => static function () {
									return __( 'The globally unique identifier for the shipping method.', 'graphql-for-ecommerce' );
								},
								'resolve'     => static function ( $edge ) {
									if ( isset( $edge['node'] ) ) {
										$shipping_method = $edge['node']->as_WC_Data();
										$instance_id     = $shipping_method->instance_id;

										return ! empty( $instance_id ) ? \GraphQLRelay\Relay::toGlobalId( 'shipping_zone_method', $instance_id ) : null;
									}
									return null;
								},
							],
							'instanceId' => [
								'type'        => 'Int',
								'description' => static function () {
									return __( 'Shipping method instance ID.', 'graphql-for-ecommerce' );
								},
								'resolve'     => static function ( $edge ) {
									if ( isset( $edge['node'] ) ) {
										$shipping_method = $edge['node']->as_WC_Data();
										return $shipping_method->instance_id ?? null;
									}
									return null;
								},
							],
							'order'      => [
								'type'        => 'Int',
								'description' => static function () {
									return __( 'The order of the shipping method.', 'graphql-for-ecommerce' );
								},
								'resolve'     => static function ( $edge ) {
									if ( isset( $edge['node'] ) ) {
										$shipping_method = $edge['node']->as_WC_Data();
										return $shipping_method->method_order ?? null;
									}
									return null;
								},
							],
							'enabled'    => [
								'type'        => 'Boolean',
								'description' => static function () {
									return __( 'Whether the shipping method is enabled.', 'graphql-for-ecommerce' );
								},
								'resolve'     => static function ( $edge ) {
									if ( isset( $edge['node'] ) ) {
										/** @var \WC_Shipping_Method $shipping_method */
										$shipping_method = $edge['node']->as_WC_Data();
										return $shipping_method->is_enabled();
									}
									return false;
								},
							],
							'settings'   => [
								'type'        => [ 'list_of' => 'WCStringSetting' ],
								'description' => static function () {
									return __( 'Shipping method settings.', 'graphql-for-ecommerce' );
								},
								'resolve'     => static function ( $edge ) {
									$settings = [];
									if ( isset( $edge['node'] ) ) {
										$shipping_method   = $edge['node']->as_WC_Data();
										$instance_settings = $shipping_method->instance_settings;
										$fields            = $shipping_method->instance_form_fields;
										foreach ( $fields as $key => $field ) {
											$default_value = ! empty( $field['default'] ) ? $field['default'] : null;
											$value         = ! empty( $instance_settings[ $key ] ) ? $instance_settings[ $key ] : $default_value;
											$settings[]    = array_merge(
												$field,
												[
													'id' => $key,
													'value' => $value,
												]
											);
										}
									}
									return $settings;
								},
							],
						],
						'resolve'    => static function ( $source, array $args, AppContext $context, ResolveInfo $info ) {
							$resolver = new Shipping_Method_Connection_Resolver( $source, $args, $context, $info );

							return $resolver->get_connection();
						},
					],
				],
			]
		);
	}
}
