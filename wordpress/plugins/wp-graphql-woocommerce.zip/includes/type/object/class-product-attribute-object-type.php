<?php
/**
 * WPObject Type - Product_Attribute_Object_Type
 *
 * Registers ProductAttributeObject type
 *
 * @package WPGraphQL\WooCommerce\Type\WPObject
 * @since   1.0.0
 */

namespace WPGraphQL\WooCommerce\Type\WPObject;

/**
 * Class Product_Attribute_Object_Type
 */
class Product_Attribute_Object_Type {
	/**
	 * Register ProductAttributeObject type and queries to the WPGraphQL schema
	 *
	 * @return void
	 */
	public static function register() {
		register_graphql_object_type(
			'ProductAttributeObject',
			[
				'description'     => static function () {
					return __( 'Product attribute object.', 'graphql-for-ecommerce' );
				},
				'eagerlyLoadType' => true,
				'fields'          => [
					'id'          => [
						'type'        => 'ID',
						'description' => static function () {
							return __( 'Unique identifier for the product attribute.', 'graphql-for-ecommerce' );
						},
						'resolve'     => static function ( $source ) {
							return ! empty( $source->attribute_id ) ? $source->attribute_id : null;
						},
					],
					'name'        => [
						'type'        => 'String',
						'description' => static function () {
							return __( 'Name of the attribute.', 'graphql-for-ecommerce' );
						},
						'resolve'     => static function ( $source ) {
							return ! empty( $source->attribute_name ) ? (string) $source->attribute_name : null;
						},
					],
					'label'       => [
						'type'        => 'String',
						'description' => static function () {
							return __( 'Label of the attribute.', 'graphql-for-ecommerce' );
						},
						'resolve'     => static function ( $source ) {
							return ! empty( $source->attribute_label ) ? (string) $source->attribute_label : null;
						},
					],
					'type'        => [
						'type'        => 'String',
						'description' => static function () {
							return __( 'Type of the attribute.', 'graphql-for-ecommerce' );
						},
						'resolve'     => static function ( $source ) {
							return ! empty( $source->attribute_type ) ? (string) $source->attribute_type : null;
						},
					],
					'orderBy'     => [
						'type'        => 'String',
						'description' => static function () {
							return __( 'Order by which the attribute should be sorted.', 'graphql-for-ecommerce' );
						},
						'resolve'     => static function ( $source ) {
							return ! empty( $source->attribute_orderby ) ? (string) $source->attribute_orderby : null;
						},
					],
					'hasArchives' => [
						'type'        => 'Boolean',
						'description' => static function () {
							return __( 'Whether or not the attribute has archives.', 'graphql-for-ecommerce' );
						},
						'resolve'     => static function ( $source ) {
							return isset( $source->attribute_public ) ? $source->attribute_public : false;
						},
					],
				],
			]
		);
	}
}
