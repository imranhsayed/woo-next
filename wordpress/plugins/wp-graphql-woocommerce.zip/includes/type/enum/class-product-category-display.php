<?php
/**
 * WPEnum Type - ProductCategoryDisplay
 *
 * @package WPGraphQL\WooCommerce\Type\WPEnum
 * @since   0.6.0
 */

namespace WPGraphQL\WooCommerce\Type\WPEnum;

/**
 * Class Product_Category_Display
 */
class Product_Category_Display {
	/**
	 * Registers type
	 *
	 * @return void
	 */
	public static function register() {
		register_graphql_enum_type(
			'ProductCategoryDisplay',
			[
				'description' => static function () {
					return __( 'Product category display type enumeration', 'graphql-for-ecommerce' );
				},
				'values'      => [
					'DEFAULT'       => [
						'value'       => 'default',
						'description' => static function () {
							return __( 'Display default content connected to this category.', 'graphql-for-ecommerce' );
						},
					],
					'PRODUCTS'      => [
						'value'       => 'products',
						'description' => static function () {
							return __( 'Display products associated with this category.', 'graphql-for-ecommerce' );
						},
					],
					'SUBCATEGORIES' => [
						'value'       => 'subcategories',
						'description' => static function () {
							return __( 'Display subcategories of this category.', 'graphql-for-ecommerce' );
						},
					],
					'BOTH'          => [
						'value'       => 'both',
						'description' => static function () {
							return __( 'Display both products and subcategories of this category.', 'graphql-for-ecommerce' );
						},
					],
				],
			]
		);
	}
}
