=== GraphQL for eCommerce ===
Contributors: kidunot89, ranaaterning, jasonbahl, saleebm
Tags: GraphQL, WooCommerce, WPGraphQL
Requires at least: 6.3
Tested up to: 7.0
Requires PHP: 8.1
Requires WooCommerce: 9.0.0
Requires WPGraphQL: 2.0.0
Works with WPGraphQL-JWT-Authentication: 0.7.0+
Stable tag: 1.0.3
License: GPL-3
License URI: https://www.gnu.org/licenses/gpl-3.0.html
Maintained at: https://github.com/wp-graphql/wp-graphql-woocommerce

== Description ==
Adds WooCommerce functionality to the WPGraphQL schema.

== Usage ==
1. Install & activate [WooCommerce](https://woocommerce.com/)
2. Install & activate [WPGraphQL](https://www.wpgraphql.com/)
3. Download the latest release from [here](https://github.com/wp-graphql/wp-graphql-woocommerce/releases) or Clone / download the zip of this repository into your WordPress plugin directory, run `composer install` in plugin directory & activate the **WP GraphQL WooCommerce** plugin.
4. (Optional) Install & activate [WPGraphQL-JWT-Authentication](https://github.com/wp-graphql/wp-graphql-jwt-authentication) to add a `login` mutation that returns a JSON Web Token.
5. (Optional) Install & activate [WPGraphQL-CORS](https://github.com/funkhaus/wp-graphql-cors) to add an extra layer of security using HTTP CORS and some of WPGraphQL advanced functionality.
